export const ORDER_DEPART = 1;
export const ORDER_DURATION = 2;
