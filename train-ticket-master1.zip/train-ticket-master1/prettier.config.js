module.exports = {
    tabWidth: 4,
    singleQuote: true,
    trailingComma: 'es5',
};
